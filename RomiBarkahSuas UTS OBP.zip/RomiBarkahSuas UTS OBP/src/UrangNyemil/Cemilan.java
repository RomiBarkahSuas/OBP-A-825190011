package UrangNyemil;

public class Cemilan {
    String name,brand,Khas;
    int stock;

    //constructor
    public Cemilan(String name,String brand, String khas, int stock){
        this.name=name;
        this.brand=brand;
        this.Khas=khas;
        this.stock=stock;
    }

    public Cemilan(){
        System.out.println("Punten Mau Info Brand Baru Ranginang");
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getKhas() {
        return Khas;
    }

    public void setKhas(String khas) {
        Khas = khas;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public void pemilik() {
        System.out.println(this.name + "RomiKasep" + this.brand);
    }
    public void khas(){
        System.out.println(this.name + "CemilanKhasSunda" + this.Khas);
    }
    public void barang(){
        if(stock >= 20){
            System.out.println("Ranginang Siap Dijual");
        }
    }



}
