package UrangNyemil;

public class Ranginang extends Cemilan{
    private static int stock;


    public Ranginang(String name, String brand, String khas, int stock) {
        super(name, brand, khas, stock);
    }
    public static void main(String[] args) {
        Cemilan Cemilan= new Cemilan();

        Cemilan.name = "RomiKasep";
        Cemilan.brand = "Dahar";
        Cemilan.Khas = "CemilanKhasSunda";
        Cemilan.stock= 30;


        System.out.println(" Ngopi name = " + Cemilan.name);
        System.out.println(" Ngopi Brand = " + Cemilan.brand);
        System.out.println(" Ngopi Khas = "+ Cemilan.Khas);
    }
}

